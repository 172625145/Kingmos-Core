#ifndef __EPROCESS_H
#define __EPROCESS_H


//HINSTANCE WINAPI KL_GetModuleInstance( void );
//HANDLE KL_GetOwnerProcess( void );
//HANDLE KL_GetParentProcess( void );

#endif  //__EPROCESS_H



