#ifndef __EPINTR_H
#define __EPINTR_H

// install ISR and Enable intr
//BOOL INTR_Initialize( DWORD idISR, LPISR lpisrFun, DWORD dwISRData,
//					  DWORD idInt, LPVOID lpvData, DWORD dwData );



#endif   //__EPINTR_H



