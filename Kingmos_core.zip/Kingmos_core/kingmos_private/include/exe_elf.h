
#ifndef		__KINGMOS_EXE_ELF_H_
#define		__KINGMOS_EXE_ELF_H_	

/*
#define   FILE_ATTR_READONLY             0x00000001
#define   FILE_ATTR_HIDDEN               0x00000002			//H
#define   FILE_ATTR_SYSTEM               0x00000004			//S
#define	  FILE_ATTR_EXE					 0x00000010			
#define	  FILE_ATTR_OBJ					 0x00000020
//#define   FILE_ATTR_DIRECTORY            0x00000010			
//#define   FILE_ATTR_ARCHIVE              0x00000020
#define   FILE_ATTR_INROM                0x00000040			
//#define   FILE_ATTR_ENCRYPTED            0x00000040
//#define   FILE_ATTR_NORMAL               0x00000080
//#define   FILE_ATTR_TEMPORARY            0x00000100
//#define   FILE_ATTR_SPARSE_FILE          0x00000200
//#define   MODULE_ATTR_NOT_TRUSTED             0x00000200
//#define   FILE_ATTRIBUTE_REPARSE_POINT        0x00000400
//#define   MODULE_ATTR_NODEBUG                 0x00000400
#define   FILE_ATTR_COMPRESSED           0x00000800			//C
//#define   FILE_ATTR_OFFLINE              0x00001000
//#define   FILE_ATTR_ROMSTATICREF         0x00001000
//#define   FILE_ATTR_NOT_CONTENT_INDEXED  0x00002000
#define	  FILE_ATTR_ROMMODULE            0x00002000
#define	  FILE_ATTR_ROMFILE		         0x00004000
*/

#endif


