#ifndef __EWINCORE_H
#define __EWINCORE_H


#endif   //__EWINCORE_H

