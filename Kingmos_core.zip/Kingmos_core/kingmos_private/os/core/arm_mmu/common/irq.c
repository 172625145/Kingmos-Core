#include <edef.h>

//#include <isr.h>

void Init_IRQ(void)
{
	ISR_Init();
}
