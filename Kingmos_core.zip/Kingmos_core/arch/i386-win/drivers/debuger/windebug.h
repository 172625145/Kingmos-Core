#ifndef __WINDEBUG_H
#define __WINDEBUG_H

#define WM_OUTDEBUGTEXTLINE (WM_USER+1)

#endif //__WINDEBUG_H
