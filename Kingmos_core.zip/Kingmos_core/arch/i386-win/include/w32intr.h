#ifndef __W32INTR_H
#define __W32INTR_H


#define ID_INTR_MOUSE    0
#define ID_INTR_KEYBOARD 1
#define ID_INTR_TIMER0   2
#define ID_INTR_TIMER1   3


#endif //__W32INTR_H




