//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by kingmos.rc
//
#define IDB_DESKTOP                     101
#define IDD_DEBUGWINDOW                 108
#define IDD_DBGWINDOW                   108
#define IDI_ICON                        109
#define IDB_LOGO                        110
#define IDI_ICON1                       114
#define SB_CLOSE                        117
#define SB_UPARROW                      121
#define IDC_OUTWINDOW                   1001
#define IDC_CHECK1                      1005
#define IDC_START                       1015
#define IDC_STOP                        1016
#define IDC_BUTTON2                     1027
#define IDC_RADIO1                      1029
#define IDC_LIST1                       1033
#define IDC_BUTTON1                     1035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        159
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
