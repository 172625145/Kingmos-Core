#include <ewindows.h>

void RegisterInlineProgram( void )
{
	// example: RegisterApplication( "Sample", WinMain_Sample, 0 );
	// if load use: LoadApplication( "Sample", "cmdline" );
}
