#ifndef __KINGMOS_DEF_H__
#define __KINGMOS_DEF_H__


#define	HW_PCB_VERSION_C

#define	SA1110DB
#define SA1111DB
#define USING_SA1111
#define USING_SA11X1

#define DEBUG_PORT_UART1

#define	WM9705TOUCH

#endif

