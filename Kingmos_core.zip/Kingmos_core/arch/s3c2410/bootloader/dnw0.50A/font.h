#ifndef __FONT_H__
#define __FONT_H__

void SetFont(HWND hwndEdit);
void ReleaseFont(void);

#endif //__FONT_H__