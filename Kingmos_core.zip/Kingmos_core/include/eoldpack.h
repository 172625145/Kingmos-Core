/**************************************************************************
* Copyright (c)  ΢�߼�(WEILUOJI). All rights reserved.                   *
**************************************************************************/


#ifndef __EPACK_H_
#define __EPACK_H_
//#include "ewindows.h"

int Pack( LPBYTE Src, LPBYTE Obj, int SrcLen);
int UnPack( LPBYTE Src, LPBYTE Obj, int SrcLen);
#endif     //__EPACK_H
