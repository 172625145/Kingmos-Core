#ifndef __EDATESET_H
#define __EDATESET_H

#ifndef __EFRAME_H
#include <eframe.h>
#endif //__EFRAME_H



// This is updown32 message
#define SDM_GETDATETIME             0x5001
#define SDM_SETDATETIME             0x5002

#endif  //__EUPDOWN_H
