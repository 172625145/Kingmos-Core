/******************************************************
Copyright(c) ��Ȩ���У�1998-2003΢�߼�����������Ȩ����
******************************************************/

#ifndef __SHOWSTYLE_H
#define __SHOWSTYLE_H

#ifdef __cplusplus
extern "C" {
#endif      /* __cplusplus */

#include "ewindows.h"


void LoadSystemStyle();
void SetSystemStyle(UINT uStyle);
UINT GetSystemStyle(void);

#ifdef __cplusplus
}
#endif  /* __cplusplus */


#endif //__SHOWSTYLE_H
