/******************************************************
Copyright(c) ��Ȩ���У�1998-2003΢�߼�����������Ȩ����
******************************************************/

#ifndef __ESTKSTR_H
#define __ESTKSTR_H

#ifdef __cplusplus
extern "C" {
#endif      // __cplusplus

// stock string
extern const TCHAR str_yes[];
extern const TCHAR str_no[];
extern const TCHAR str_cancel[];
extern const TCHAR str_close[];
extern const TCHAR str_help[];
extern const TCHAR str_error[];
extern const TCHAR str_ok[];
extern const TCHAR str_save[];
extern const TCHAR str_saveas[];
extern const TCHAR str_open[];
 
#ifdef __cplusplus
}
#endif  // __cplusplus

#endif    // __ESTKSTR_H
