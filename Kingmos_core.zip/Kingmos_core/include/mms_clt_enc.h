

extern	BOOL	MClt_PickPdu( MMS_PDU* pPduMms, OUT MCLT_PDU* pPduMClt, BYTE bMsgType, OUT ERROR_INFO* pInfoErr );
