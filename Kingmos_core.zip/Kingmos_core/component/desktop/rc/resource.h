//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Shell.rc
//
#define IDB_ENGNORMAL                   101
#define IDB_ENGSEL                      102
#define IDB_PYNORMAL                    103
#define IDB_PYSEL                       104
#define IDB_APPBAR                      105
#define IDI_COMPUTER                    106
#define IDB_MENU                        107
#define IDB_KEYBOARD                    108
#define IDI_KEYBOARD                    109
#define IDI_MENU                        110

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
