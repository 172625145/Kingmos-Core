/**************************************************************************
* Copyright (c)  ΢�߼�(WEILUOJI). All rights reserved.                   *
**************************************************************************/
#ifndef __SHELLAPI_H__
#define __SHELLAPI_H__

#ifdef __cplusplus
extern "C" {
#endif      /* __cplusplus */

VOID WINAPI Shell_SHChangeNotify(LONG wEventId, UINT uFlags, LPCVOID dwItem1, LPCVOID dwItem2);

#ifdef __cplusplus
}
#endif  /* __cplusplus */


#endif
