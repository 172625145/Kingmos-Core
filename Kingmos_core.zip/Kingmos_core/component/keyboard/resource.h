//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by desktop.rc
//
#define IDI_GPSCLOSE                    101
#define IDI_GPSSIGN0                    103
#define IDI_GPSSIGN1                    104
#define IDI_GPSSIGN2                    105
#define IDI_GPSSIGN3                    106
#define IDI_GPSSIGN4                    107
#define IDI_GPSSIGN5                    108
#define IDI_PHONECLOSE                  111
#define IDI_PHONESIGN0                  112
#define IDI_PHONESIGN1                  113
#define IDI_PNOGSIGN1                   114
#define IDI_PHONESIGN2                  115
#define IDI_PNOGSIGN2                   116
#define IDI_PNOGSIGN3                   117
#define IDI_PHONESIGN3                  118
#define IDI_PHONESIGN4                  119
#define IDI_PNOGSIGN4                   120
#define IDI_PHONESIGN5                  121
#define IDI_PNOGSIGN5                   122
#define IDI_CLOCKON                     123
#define IDI_NEWMESSAGE                  124
#define IDI_CALLMISSED                  125
#define IDI_MESSAGEFULL                 126
#define IDI_NORING                      127
#define IDI_SOUNDOK                     128
#define IDI_SOUNDMUTE                   129
#define IDI_HOMEPAGE                    130
#define IDI_PHONEPAGE                   131
#define IDI_APPPAGE                     132
#define IDI_SETTING                     133
#define IDI_BATTERY0                    134
#define IDI_BATTERY1                    135
#define IDI_BATTERY2                    136
#define IDI_BATTERY3                    137
#define IDI_BATTERY4                    138
#define IDI_BATTERY5                    139
#define IDI_TELRECORD                   140
#define IDI_NAMECARD                    141
#define IDI_MESSBOX                     142
#define IDI_IEBROWSER                   143
#define IDI_EASYBOX                     144
#define IDI_STKSERVER                   145
#define IDI_GPSMAP                      146
#define IDI_FILEVIEW                    147
#define IDI_CALENDAR                    148
#define IDI_MP3                         149
#define IDI_DICTIONARY                  150
#define IDI_READBOOK                    151
#define IDI_CALCULATOR                  152
#define IDI_RECORD                      153
#define IDI_GAME                        154
#define IDI_CAMERA                      155
#define IDI_OWNER                       156
#define IDI_TELSET                      157
#define IDI_GPSSET                      158
#define IDI_TIMECLOCK                   159
#define IDI_DISPLAY                     160
#define IDI_STYLUS                      161
#define IDI_PASSSET                     162
#define IDI_VOLUME                      163
#define IDI_SYSTEM                      164
#define IDI_NETLINK                     165
#define IDI_GAMEEXIT                    166
#define IDI_FLYBAT                      167
#define IDI_MOBILE                      168
#define IDB_TABBACKGROUND               169
#define IDB_WORKAREABACKGROUND          170
#define IDB_NUMBER                      173
#define IDI_ALBUM                       222
#define IDB_ARROWDIS                    228
#define IDB_HANDWRITE                   229
#define IDB_PINYIN                      230
#define IDB_SYMBOL                      231

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        233
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
